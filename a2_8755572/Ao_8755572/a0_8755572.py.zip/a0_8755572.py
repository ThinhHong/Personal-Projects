print("printing from a file")
